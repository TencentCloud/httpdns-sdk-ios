//
//  MSDKDnsHttpMessageTools.h
//  MSDKDnsDevDemo
//
//  Created by fu chunhui on 2017/4/23.
//  Copyright © 2017年 Tencent. All rights reserved.
//

@interface MSDKDnsHttpMessageTools : NSURLProtocol

@end
